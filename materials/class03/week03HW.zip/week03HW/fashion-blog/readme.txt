Complete the fashion blog from the attached screenshot. Take a look at the copy.txt for what to plug into the HTML.

Some values you will also need:

Content:
    720px wide
    54px of padding
    solid, left, 6px, border, #dddddd

High-level text properties:
    #444444
    "Lato" font
    1.5 line-height

"Better Dressed People":
    black

Links:
    #DD0000

Links hover:
    #aa0000

Navigation links:
    #dddddd

Navigation links hover:
    black

Date: 
    #cccccc

Article Title
    black

Copyright
    #bbbbbb

If we were working with a real design document, you would be able to get the precise pixel values for line height, font size, margin, padding, etc. Just approximate as best you can.